﻿using System;

namespace Charris4Challenge1
{
    class Program
    {
        static void Main(string[] args)
        {
            Gameboard board = new Gameboard();
            board.FillGrid();
            board.Display();

        }//Main

    }//Program

}//Charris4Challenge1




//Dude this is
