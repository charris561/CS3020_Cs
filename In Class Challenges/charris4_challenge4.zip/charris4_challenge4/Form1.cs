namespace charris4_challenge4
{
    public partial class Form1 : Form
    {
        public bool userAuthenticated;
        public bool coordset;
        public bool abortFiring;
        public Form1()
        {
            InitializeComponent();

            
        }

        private void FireButtonClickHandler(object sender, EventArgs e)
        {
            
        }
    }
}